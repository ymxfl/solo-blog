title: CentOS升级docker版本到最新版本
date: '2019-11-03 20:22:14'
updated: '2019-11-03 21:13:35'
tags: [docker, linux]
permalink: /articles/2019/11/03/1572783734846.html
---
![](https://img.hacpai.com/bing/20180506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**今天在搭建code-push-server中，通过docker-stack deploy部署时，报了个错，错误内容如下：**
```shell
[code-push@VM_0_13_centos docker]$ sudo docker stack deploy -c docker-compose.yml code-push-server
unsupported Compose file version: 3.7
```
查了一些资料，找到这篇文章 # [Dockerfile & Docker Swarm & Docker Stack & Docker Compose](https://www.cnblogs.com/LUA123/p/11453308.html)
作者对Dockerfile、Docker Swarm、Docker Stack、Docker Compose几个指令做了详细的解释。![image.png](https://img.hacpai.com/file/2019/11/image-d4ca25cf.png)
在Docker Compose版本与docker版本的对应关系中找到了我这个错误的原因，是因为我当前docker版本是1.13.1(可以通过docker info或者docker version查看当前docker版本)，而我下载的code-push-server里的compose版本是3.7，所以报错了。那么接下来就是要升级一下docker版本了。
### 升级docker到最新版本
* **第一步：查找主机上关于Docker的软件包**
`rpm -qa | grep docker` – – 列出包含docker字段的软件的信息
```shell
[root@VM_0_13_centos ~]# rpm -qa | grep docker
docker-1.13.1-103.git7f2769b.el7.centos.x86_64
docker-client-1.13.1-103.git7f2769b.el7.centos.x86_64
docker-common-1.13.1-103.git7f2769b.el7.centos.x86_64
```
* **第二步：使用yum remove 卸载软件**
```shell
[root@VM_0_13_centos ~]# yum remove docker-1.13.1-103.git7f2769b.el7.centos.x86_64
[root@VM_0_13_centos ~]# yum remove docker-client-1.13.1-103.git7f2769b.el7.centos.x86_64
[root@VM_0_13_centos ~]# yum remove docker-common-1.13.1-103.git7f2769b.el7.centos.x86_64
```
* **第三步：使用curl升级到最新版本**
```shell
[root@VM_0_13_centos ~]# curl -fsSL https://get.docker.com/ | sh
# Executing docker install script, commit: f45d7c11389849ff46a6b4d94e0dd1ffebca32c1
+ sh -c 'yum install -y -q yum-utils'
Repository epel is listed more than once in the configuration
Package yum-utils-1.1.31-52.el7.noarch already installed and latest version
+ sh -c 'yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo'
Loaded plugins: fastestmirror, langpacks
Repository epel is listed more than once in the configuration
adding repo from: https://download.docker.com/linux/centos/docker-ce.repo
grabbing file https://download.docker.com/linux/centos/docker-ce.repo to /etc/yum.repos.d/docker-ce.repo
repo saved to /etc/yum.repos.d/docker-ce.repo
+ '[' stable '!=' stable ']'
+ sh -c 'yum makecache'
Loaded plugins: fastestmirror, langpacks
Repository epel is listed more than once in the configuration
Loading mirror speeds from cached hostfile
 * elrepo: mirrors.tuna.tsinghua.edu.cn
docker-ce-stable                                                                                                                     | 3.5 kB  00:00:00
http://mirror-hk.koddos.net/elrepo/elrepo/el7/x86_64/repodata/repomd.xml: [Errno 14] curl#7 - "Failed connect to mirror-hk.koddos.net:80; No route to host"
Trying other mirror.
elrepo                                                                                                                               | 2.9 kB  00:00:00
Not using downloaded elrepo/repomd.xml because it is older than what we have:
  Current   : Sun Nov  3 16:15:03 2019
  Downloaded: Sun Nov  3 13:15:03 2019
epel                                                                                                                                 | 5.4 kB  00:00:00
extras                                                                                                                               | 2.9 kB  00:00:00
os                                                                                                                                   | 3.6 kB  00:00:00
updates                                                                                                                              | 2.9 kB  00:00:00
(1/14): docker-ce-stable/x86_64/updateinfo                                                                                           |   55 B  00:00:00
(2/14): docker-ce-stable/x86_64/filelists_db                                                                                         |  18 kB  00:00:00
(3/14): docker-ce-stable/x86_64/primary_db                                                                                           |  37 kB  00:00:00
(4/14): epel/7/x86_64/prestodelta                                                                                                    | 5.2 kB  00:00:00
(5/14): docker-ce-stable/x86_64/other_db                                                                                             | 111 kB  00:00:00
(6/14): epel/7/x86_64/other_db                                                                                                       | 3.3 MB  00:00:00
(7/14): epel/7/x86_64/updateinfo_zck                                                                                                 | 1.5 MB  00:00:00
(8/14): extras/7/x86_64/other_db                                                                                                     | 100 kB  00:00:00
(9/14): os/7/x86_64/other_db                                                                                                         | 2.6 MB  00:00:00
(10/14): extras/7/x86_64/filelists_db                                                                                                | 207 kB  00:00:00
(11/14): updates/7/x86_64/other_db                                                                                                   | 243 kB  00:00:00
(12/14): updates/7/x86_64/filelists_db                                                                                               | 2.1 MB  00:00:00
(13/14): os/7/x86_64/filelists_db                                                                                                    | 7.3 MB  00:00:00
(14/14): epel/7/x86_64/filelists_db                                                                                                  |  12 MB  00:00:02
(1/2): elrepo/other_db                                                                                                               |  34 kB  00:00:00
(2/2): elrepo/filelists_db                                                                                                           |  39 kB  00:00:00
Metadata Cache Created
+ '[' -n '' ']'
+ sh -c 'yum install -y -q docker-ce'
Repository epel is listed more than once in the configuration
warning: /var/cache/yum/x86_64/7/docker-ce-stable/packages/docker-ce-19.03.4-3.el7.x86_64.rpm: Header V4 RSA/SHA512 Signature, key ID 621e9f35: NOKEY
Public key for docker-ce-19.03.4-3.el7.x86_64.rpm is not installed
Importing GPG key 0x621E9F35:
 Userid     : "Docker Release (CE rpm) <docker@docker.com>"
 Fingerprint: 060a 61c5 1b55 8a7f 742b 77aa c52f eb6b 621e 9f35
 From       : https://download.docker.com/linux/centos/gpg
If you would like to use Docker as a non-root user, you should now consider
adding your user to the "docker" group with something like:

  sudo usermod -aG docker your-user

Remember that you will have to log out and back in for this to take effect!

WARNING: Adding a user to the "docker" group will grant the ability to run
         containers which can be used to obtain root privileges on the
         docker host.
         Refer to https://docs.docker.com/engine/security/security/#docker-daemon-attack-surface
         for more information.
```
* **第四步：重启Docker**
`[root@VM_0_13_centos ~]# systemctl restart docker`
* **第五步：设置Docker开机自启**
`[root@VM_0_13_centos ~]# systemctl enable docker`
* **第六步：查看docker信息**
```shell
[root@VM_0_13_centos ~]# docker version
Client: Docker Engine - Community
 Version:           19.03.4
 API version:       1.40
 Go version:        go1.12.10
 Git commit:        9013bf583a
 Built:             Fri Oct 18 15:52:22 2019
 OS/Arch:           linux/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.4
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.10
  Git commit:       9013bf583a
  Built:            Fri Oct 18 15:50:54 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.2.10
  GitCommit:        b34a5c8af56e510852c35414db4c1f4fa6172339
 runc:
  Version:          1.0.0-rc8+dev
  GitCommit:        3e425f80a8c931f88e6d94a8c831b9d5aa481657
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683
```
可以看到docker版本已经升级到了19.03.4
### 重启旧容器
升级完Docker版本之后，原先的镜像需要重新启动，通过`docker images`命令可以看到之前的镜像，使用`docker ps -a`可以看到停止的容器。
```shell
[root@VM_0_13_centos ~]# docker images
REPOSITORY            TAG                 IMAGE ID            CREATED             SIZE
nginx                 latest              5a9061639d0a        2 weeks ago         126MB
b3log/solo            latest              dcdb7cb3ca38        2 weeks ago         151MB
b3log/lute-http       latest              1aa3c892dc68        4 weeks ago         20.9MB
[root@VM_0_13_centos ~]# docker ps -a
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS                       PORTS               NAMES
68ce54922a68        dcdb7cb3ca38        "java -cp WEB-INF/li…"   2 weeks ago         Exited (143) 3 minutes ago                       solo
9ec87b60e275        5a9061639d0a        "nginx -g 'daemon of…"   2 weeks ago         Exited (0) 3 minutes ago                         nginx
2c8ba9a68c0c        383867b75fd2        "docker-entrypoint.s…"   3 weeks ago         Exited (0) 3 minutes ago                         mysql
```
* **第七步：使用`docker start container-name/container-id`启动容器**
```shell
[root@VM_0_13_centos ~]# docker start nginx
Error response from daemon: Unknown runtime specified docker-runc
Error: failed to start containers: nginx
```
**这里报了个错：Error response from daemon: Unknown runtime specified docker-runc**
**查阅资料后得知这是当您从不兼容的版本升级docker并且升级后无法启动docker容器时会出现这种情况，解决办法如下**
```shell
[root@VM_0_13_centos ~]# grep -rl 'docker-runc' /var/lib/docker/containers/ | xargs sed -i 's/docker-runc/runc/g'
[root@VM_0_13_centos ~]# systemctl stop docker
[root@VM_0_13_centos ~]# systemctl start docker
```
然后再启动之前的容器就可以了。
