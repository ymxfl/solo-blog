title: React-Native Android集成Code-Push 热更新
date: '2019-11-07 23:47:24'
updated: '2019-11-10 19:21:40'
tags: [react-native]
permalink: /articles/2019/11/07/1573141644720.html
---
![](https://img.hacpai.com/bing/20190103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1. code-push常用命令

* **安装客户端**: `npm install -g code-push-cli`
* **注册账号**: `code-push register`(自建服务不需要注册)
* **登陆**: `code-push login <address>`
例如：
```
code-push login http://localhost:3000
```
![image.png](https://img.hacpai.com/file/2019/11/image-9a75d2a1.png)

执行完后会自动打开浏览器,输入用户密码密码后跳转到获取token页面

![image.png](https://img.hacpai.com/file/2019/11/image-7e17565c.png)

点击获取token，将生成的token复制到控制台

![image.png](https://img.hacpai.com/file/2019/11/image-28ba71c8.png)

![image.png](https://img.hacpai.com/file/2019/11/image-4ec23e6a.png)

此处可以看到登陆成功，并且将登陆信息持久化保存到了文件里，只要文件不删除，就不需要重新登陆。`Your session file was written to C:\Users\42556\AppData\Local\.code-push.config`，当再次登陆时会提示!

[image.png](https://img.hacpai.com/file/2019/11/image-f8075c39.png)


* **注销**: `code-push logout`
注销登陆时会删除用户本地存储的登录信息，当遇到不能正常注销时，可手动删除.code-push.config文件

![image.png](https://img.hacpai.com/file/2019/11/image-7d26536a.png)

* **添加项目**: `code-push app add [app名称] android/ios react-native`
注意：**一定要为 Android 和 iOS 分别注册**，两者的更新包内容会有差异，这里建议在App名称后加上操作系统类型如Android或Ios以方便区分。

![image.png](https://img.hacpai.com/file/2019/11/image-1d456e1d.png)

添加成功后会返回不同运行时环境的Key，比如 `Production`,`Staging`等。

* **删除项目**: `code-push app remove [app名称]`

![image.png](https://img.hacpai.com/file/2019/11/image-12dc5e01.png)

* **列出账号下的所有项目**:`code-push app list`

![image.png](https://img.hacpai.com/file/2019/11/image-15b4879a.png)

* **显示登陆的token**: `code-push access-key ls`

![image.png](https://img.hacpai.com/file/2019/11/image-76619a80.png)

* **删除某个access-key**: `code-push access-key rm <accessKey>`

* **添加协作人员**：`code-push collaborator add <appName> lizhenhua@agree.com.cn` 

* **添加一个部署环境**: `code-push deployment add <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-09ad19ca.png)

* **删除部署**: `code-push deployment rm <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-1588abcf.png)

* **列出应用的部署**: `code-push deployment ls <appName>`

![image.png](https://img.hacpai.com/file/2019/11/image-82918506.png)

* **查询部署环境的key**: `code-push deployment ls <appName> -k`

![image.png](https://img.hacpai.com/file/2019/11/image-f9bd214b.png)

* **查看部署的历史版本信息**: `code-push deployment history <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-f50ae398.png)

* **重命名一个部署环境名称**: `code-push deployment rename <appName> <currentDeploymentName> <newDeploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-00d90ccb.png)

### **2.集成到项目**
* **第一步：安装CodePush插件**`npm install -g code-push-cli`
安装完毕后，输入 `code-push -v`查看版本，如看到版本代表成功。
注意：自建code-push-server服务与react-native-code-push版本有强依赖关系，如果对应有问题则会导致无法正常更新，本项目rn版本`0.60.4`,使用code-push-server版本为`0.5.4`,react-native-code-push插件版本0.5.6。我尝试使用最新的code-push插件版本为0.5.7，但服务请求路径完全不配套。目前code-push与rn版本的对应关系如下![image.png](https://img.hacpai.com/file/2019/11/image-ae082d64.png)

* **第二步：引入到项目里**
	* 2.2.1 自动引入`react-native link react-native-code-push`（建议手动引入，这样清楚具体添加了哪些内容）
	* 2.2.2 手动引入
在 android/app/build.gradle文件里面添如下代码:
```js
apply from: "../../node_modules/react-native-code-push/android/codepush.gradle"
dependencies {
...
    implementation project(':react-native-code-push')
}
并修改defaultConfig中的versionName为三位(默认为1.0)，如1.0.0
```
然后在/android/settings.gradle中添加如下代码:
```js
include ':react-native-code-push'
project(':react-native-code-push').projectDir = new File(rootProject.projectDir, '../node_modules/react-native-code-push/android/app')
```
* **第三步：运行** `code-push deployment -k ls <appName>`**获取 部署秘钥**。默认的部署名是 staging，所以 部署秘钥（deployment key ） 就是 staging。

* **第四步：添加配置**。当APP启动时我们需要让app向CodePush咨询JS bundle的所在位置，这样CodePush就可以控制版本。更新 MainApplication.java文件
```java
public class MainApplication extends Application implements ReactApplication {
  private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
    @Override
    protected boolean getUseDeveloperSupport() {
      return BuildConfig.DEBUG;
    }
    @Override
    protected String getJSBundleFile() {
      return CodePush.getJSBundleFile();
    }
    @Override
    protected List<ReactPackage> getPackages() {
      // 3. Instantiate an instance of the CodePush runtime and add it to the list of
      // existing packages, specifying the right deployment key. If you don't already
      // have it, you can run "code-push deployment ls <appName> -k" to retrieve your key.
      return Arrays.<ReactPackage>asList(
        new MainReactPackage(),
        new CodePush("deployment-key-here", MainApplication.this, BuildConfig.DEBUG,"YOUR_SERVER_URL")
      );
    }
  };
  @Override
  public ReactNativeHost getReactNativeHost() {
      return mReactNativeHost;
  }
}
```
别忘了
```java
import com.microsoft.codepush.react.CodePush;
```
**关于deployment-key的设置**

在上述代码中我们在创建CodePush实例的时候需要设置一个deployment-key,因为deployment-key分生产环境与测试环境两种,所以建议大家在build.gradle中进行设置。在build.gradle中的设置方法如下:

打开android/app/build.gradle文件,找到`android { buildTypes {} }`然后添加如下代码即可:

```js
android {
    ...
    buildTypes {
        debug {
            ...
            // CodePush updates should not be tested in Debug mode
            ...
        }

        releaseStaging {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"<INSERT_STAGING_KEY>"'
            ...
        }

        release {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"<INSERT_PRODUCTION_KEY>"'
            ...
        }
    }
    ...
}
```
> 心得:另外,我们也可以将deployment-key存放在local.properties中:

```properties
code_push_key_production=erASzHa1-wTdODdPJDh6DBF2Jwo94JFH08Kvb
code_push_key_staging=mQY75RkFbX6SiZU1kVT1II7OqWst4JFH08Kvb
```
然后在就可以在android/app/build.gradle可以通过下面方式来引用它了:

```js
Properties properties = new Properties()
properties.load(project.rootProject.file('local.properties').newDataInputStream())
android {
    ...
    buildTypes {
        debug {
            ...
            // CodePush updates should not be tested in Debug mode
            ...
        }

        releaseStaging {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"'+properties.getProperty("code_push_key_production")+'"'
            ...
        }

        release {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"'+properties.getProperty("code_push_key_staging")+'"'
            ...
        }
    }
    ...
}
```
在android/app/build.gradle设置好deployment-key之后呢,我们就可以这样使用了:

```java
@Override
protected List<ReactPackage> getPackages() {
     return Arrays.<ReactPackage>asList(
         ...
         new CodePush(BuildConfig.CODEPUSH_KEY, MainApplication.this, BuildConfig.DEBUG,"YOUR_CODE_PUSH_SERVER"), // Add/change this line.
         ...
     );
}
```
至此Code Push for Android的SDK已经集成完成。

### 3.设置更新策略
在使用CodePush更新你的应用之前需要，先配置一下更新控制策略，即：

* 什么时候检查更新？（在APP启动的时候？在设置页面添加一个检查更新按钮？）
* 什么时候可以更新，如何将更新呈现给终端用户？

最简单的方式是在根component中进行上述策略控制。

1. 在 js中加载 CodePush模块：  
    `import codePush from 'react-native-code-push'`  
2.在 `componentDidMount`中调用 `sync`方法，后台请求更新  
    `codePush.sync()`

如果可以进行更新，CodePush会在后台静默地将更新下载到本地，等待APP下一次启动的时候应用更新，以确保用户看到的是最新版本。  
如果更新是强制性的，更新文件下载好之后会立即进行更新。  
如果你期望更及时的获得更新，可以在每次APP从后台进入前台的时候去主动的检查更新：  
在应用的根component的`componentDidMount`中添加如下代码：

```
AppState.addEventListener("change", (newState) => {
    newState === "active" && codePush.sync();
});
```
#### JavaScript API Reference

* allowRestart
* checkForUpdate
* disallowRestart
* getUpdateMetadata
* notifyAppReady
* restartApp
* sync

其实我们可以将这些API分为两类，一类是自动模式，一类是手动模式。

##### [](https://github.com/crazycodeboy/RNStudyNotes/tree/master/React%20Native%E5%BA%94%E7%94%A8%E9%83%A8%E7%BD%B2%E3%80%81%E7%83%AD%E6%9B%B4%E6%96%B0-CodePush%E6%9C%80%E6%96%B0%E9%9B%86%E6%88%90%E6%80%BB%E7%BB%93#%E8%87%AA%E5%8A%A8%E6%A8%A1%E5%BC%8F)自动模式

`sync`为自动模式，调用此方法CodePush会帮你完成一系列的操作。其它方法都是在手动模式下使用的。  
**codePush.sync**  
`codePush.sync(options: Object, syncStatusChangeCallback: function(syncStatus: Number), downloadProgressCallback: function(progress: DownloadProgress)): Promise<Number>;`  
通过调用该方法CodePush会帮我们自动完成检查更新，下载，安装等一系列操作。除非我们需要自定义UI表现，不然直接用这个方法就可以了。  
**sync方法，提供了如下属性以允许你定制sync方法的默认行为**

* deploymentKey （String）： 部署key，指定你要查询更新的部署秘钥，默认情况下该值来自于Info.plist(Ios)和MianActivity.java(Android)文件，你可以通过设置该属性来动态查询不同部署key下的更新。
* installMode (codePush.InstallMode)： 安装模式，用在向CodePush推送更新时没有设置强制更新(mandatory为true)的情况下，默认codePush.InstallMode.ON_NEXT_RESTART即下一次启动的时候安装。
* mandatoryInstallMode (codePush.InstallMode):强制更新,默认codePush.InstallMode.IMMEDIATE。
* minimumBackgroundDuration (Number):该属性用于指定app处于后台多少秒才进行重启已完成更新。默认为0。该属性只在`installMode`为`InstallMode.ON_NEXT_RESUME`情况下有效。
* updateDialog (UpdateDialogOptions) :可选的，更新的对话框，默认是null,包含以下属性
    * appendReleaseDescription (Boolean) - 是否显示更新description，默认false
    * descriptionPrefix (String) - 更新说明的前缀。 默认是” Description: “
    * mandatoryContinueButtonLabel (String) - 强制更新的按钮文字. 默认 to “Continue”.
    * mandatoryUpdateMessage (String) - 强制更新时，更新通知. Defaults to “An update is available that must be installed.”.
    * optionalIgnoreButtonLabel (String) - 非强制更新时，取消按钮文字. Defaults to “Ignore”.
    * optionalInstallButtonLabel (String) - 非强制更新时，确认文字. Defaults to “Install”.
    * optionalUpdateMessage (String) - 非强制更新时，更新通知. Defaults to “An update is available. Would you like to install it?”.
    * title (String) - 要显示的更新通知的标题. Defaults to “Update available”.

eg:

codePush.sync({
      updateDialog: {
        appendReleaseDescription: true,
        descriptionPrefix:'\n\n更新内容：\n',
        title:'更新',
        mandatoryUpdateMessage:'',
        mandatoryContinueButtonLabel:'更新',
      },
      mandatoryInstallMode:codePush.InstallMode.IMMEDIATE,
      deploymentKey: CODE_PUSH_PRODUCTION_KEY,
    });

##### [](https://github.com/crazycodeboy/RNStudyNotes/tree/master/React%20Native%E5%BA%94%E7%94%A8%E9%83%A8%E7%BD%B2%E3%80%81%E7%83%AD%E6%9B%B4%E6%96%B0-CodePush%E6%9C%80%E6%96%B0%E9%9B%86%E6%88%90%E6%80%BB%E7%BB%93#%E6%89%8B%E5%8A%A8%E6%A8%A1%E5%BC%8F)手动模式

**codePush.allowRestart**

`codePush.allowRestart(): void;`  
允许重新启动应用以完成更新。  
如果一个CodePush更新将要发生并且需要重启应用(e.g.设置了InstallMode.IMMEDIATE模式)，但由于调用了`disallowRestart`方法而导致APP无法通过重启来完成更新， 可以调用此方法来解除`disallowRestart`限制。  
但在如下四种情况下，CodePush将不会立即重启应用：

1. 自上一次`disallowRestart`被调用，没有新的更新。
2. 有更新，但`installMode`为`InstallMode.ON_NEXT_RESTART`的情况下。
3. 有更新，但`installMode`为`InstallMode.ON_NEXT_RESUME`，并且程序一直处于前台，并没有从后台切换到前台的情况下。
4. 自从上次`disallowRestart`被调用，没有再调用`restartApp`。

**codePush.checkForUpdate**

`codePush.checkForUpdate(deploymentKey: String = null): Promise<RemotePackage>;`  
向CodePush服务器查询是否有更新。  
该方法返回Promise，有如下两种值：

* null 没有更新  
    通常有如下情况导致RemotePackage为null:
    
    1. 当前APP版本下没有部署新的更新版本。也就是说没有想CodePush服务器推送基于当前版本的有关更新。
    2. CodePush上的更新和用户当前所安装的APP版本不匹配。也就是说CodePush服务器上有更新，但该更新对应的APP版本和用户安装的当前版本不对应。
    3. 当前APP已将安装了最新的更新。
    4. 部署在CodePush上可用于当前APP版本的更新被标记成了不可用。
    5. 部署在CodePush上可用于当前APP版本的更新是"active rollout"状态，并且当前的设备不在有资格更新的百分比的设备之内。
* A RemotePackage instance  
    有更新可供下载。
    

eg：

codePush.checkForUpdate()
.then((update) => {
    if (!update) {
        console.log("The app is up to date!");
    } else {
        console.log("An update is available! Should we download it?");
    }
});  

**codePush.disallowRestart**

`codePush.disallowRestart(): void;`  
不允许立即重启用于以完成更新。  
eg:

class OnboardingProcess extends Component {
    ...

    componentWillMount() {
        // Ensure that any CodePush updates which are
        // synchronized in the background can't trigger
        // a restart while this component is mounted.
        codePush.disallowRestart();
    }

    componentWillUnmount() {
        // Reallow restarts, and optionally trigger
        // a restart if one was currently pending.
        codePush.allowRestart();
    }

    ...
}

**codePush.getUpdateMetadata**  
`codePush.getUpdateMetadata(updateState: UpdateState = UpdateState.RUNNING): Promise<LocalPackage>;`  
获取当前已安装更新的元数据（描述、安装时间、大小等）。  
eg:

// Check if there is currently a CodePush update running, and if
// so, register it with the HockeyApp SDK (https://github.com/slowpath/react-native-hockeyapp)
// so that crash reports will correctly display the JS bundle version the user was running.
codePush.getUpdateMetadata().then((update) => {
    if (update) {
        hockeyApp.addMetadata({ CodePushRelease: update.label });
    }
});

// Check to see if there is still an update pending.
codePush.getUpdateMetadata(UpdateState.PENDING).then((update) => {
    if (update) {
        // There's a pending update, do we want to force a restart?
    }
});

**codePush.notifyAppReady**  
`codePush.notifyAppReady(): Promise<void>;`  
通知CodePush，一个更新安装好了。当你检查并安装更新，（比如没有使用sync方法去handle的时候），这个方法必须被调用。否则CodePush会认为update失败，并rollback当前版本，在app重启时。  
当使用`sync`方法时，不需要调用本方法，因为`sync`会自动调用。

**codePush.restartApp**  
`codePush.restartApp(onlyIfUpdateIsPending: Boolean = false): void;`  
立即重启app。 当以下情况时，这个方式是很有用的：

1. app 当 调用 `sync` 或 `LocalPackage.install` 方法时，指定的 `install mode `是 `ON_NEXT_RESTART` 或 `ON_NEXT_RESUME时` 。 这两种情况都是当app重启或`resume`时，更新内容才能被看到。
2. 在特定情况下，如用户从其它页面返回到APP的首页时，这个时候调用此方法完成过更新对用户来说不是特别的明显。因为强制重启，能马上显示更新内容。

### 4.发布更新
CodePush支持两种发布更新的方式，一种是通过`code-push release-react`简化方式，另外一种是通过`code-push release`的复杂方式。

> **第一种方式：通过`code-push release-react`发布更新**

这种方式将打包与发布两个命令合二为一，可以说大大简化了我们的操作流程，建议大家多使用这种方式来发布更新。

命令格式：

```bash
code-push release-react <appName> <platform>

```

eg:

```bash
code-push release-react MyApp-iOS ios
code-push release-react MyApp-Android android

```

再来个更高级的：

```bash
code-push release-react MyApp-iOS ios  --t 1.0.0 --dev false --d Production --des "1.优化操作流程" --m true

```

其中参数--t为二进制(.ipa与apk)安装包的的版本；--dev为是否启用开发者模式(默认为false)；--d是要发布更新的环境分Production与Staging(默认为Staging)；--des为更新说明；--m 是强制更新。

关于`code-push release-react`更多可选的参数，可以在终端输入`code-push release-react`进行查看。

另外，我们可以通过`code-push deployment ls <appName>`来查看发布详情与此次更新的安装情况。
> **第二种方式：通过`code-push release`发布更新**

`code-push release`发布更新呢我们首先需要将js与图片资源进行打包成 bundle。

##### [](https://github.com/crazycodeboy/RNStudyNotes/tree/master/React%20Native%E5%BA%94%E7%94%A8%E9%83%A8%E7%BD%B2%E3%80%81%E7%83%AD%E6%9B%B4%E6%96%B0-CodePush%E6%9C%80%E6%96%B0%E9%9B%86%E6%88%90%E6%80%BB%E7%BB%93#%E7%94%9F%E6%88%90bundle)生成bundle

发布更新之前，需要先把 js打包成 bundle，如：

第一步： 在 工程目录里面新增 bundles文件：`mkdir bundles`

第二步： 运行命令打包 `react-native bundle --platform 平台 --entry-file 启动文件 --bundle-output 打包js输出文件 --assets-dest 资源输出目录 --dev 是否调试`。  
eg:  
`react-native bundle --platform android --entry-file index.android.js --bundle-output ./bundles/index.android.bundle --dev false`
![image.png](https://img.hacpai.com/file/2019/11/image-d47a05b9.png)
**需要注意的是：**

* 忽略了资源输出是因为 输出资源文件后，会把bundle文件覆盖了。
* 输出的bundle文件名不叫其他，而是 index.android.bundle，是因为 在debug模式下，工程读取的bundle就是叫做 index.android.bundle。
* 平台可以选择 android 或者 ios。
##### 发布更新

打包bundle结束后，就可以通过CodePush发布更新了。在终端输入  
```
code-push release <应用名称> <Bundles所在目录> <对应的应用版本> --deploymentName： 更新环境 --description： 更新描述 --mandatory： 是否强制更新
``` 
eg:  
```
code-push release MbankAndroid ./bundles/index.android.bundle 1.0.0 --deploymentName Production --description "1.更新测试。" --mandatory true
```
上面仅仅是发布js文件，如果要带资源一起发布，用下面方式
```
code-push release MbankAndroid ./bundles 1.0.0 --deploymentName Production --description "1.更新测试。" --mandatory true
```
![image.png](https://img.hacpai.com/file/2019/11/image-d5f3c5be.png)

**注意：**

1. CodePush默认是更新 staging 环境的，如果是staging，则不需要填写 deploymentName。
2. 如果有 mandatory 则Code Push会根据mandatory 是true或false来控制应用是否强制更新。默认情况下mandatory为false即不强制更新。
3. 对应的应用版本（targetBinaryVersion）是指当前app的版本(对应build.gradle中设置的versionName "1.0.0")，也就是说此次更新的js/images对应的是app的那个版本。不要将其理解为这次js更新的版本。 如客户端版本是 1.0.0，那么我们对1.0.0的客户端更新js/images，targetBinaryVersion填的就是1.0.0。
4. 对于对某个应用版本进行多次更新的情况，CodePush会检查每次上传的 bundle，如果在该版本下如1.0.0已经存在与这次上传完全一样的bundle(对应一个版本有两个bundle的md5完全一样)，那么CodePush会拒绝此次更新。 
5. 在终端输入 `code-push deployment history <appName> Staging` 可以看到Staging版本更新的时间、描述等等属性。
![非强制更新](https://img.hacpai.com/file/2019/11/image-3e45fddf.png)
![强制更新](https://img.hacpai.com/file/2019/11/image-263a25ea.png)

应用启动之后，从CodePush服务器查询更新，并下载到本地，下载好之后，提示用户进行更新，上图分别是非强制更新和强制更新。这就是CodePush用于热更新的整个过程。


