title: xxx is not in the sudoers file.This incident will be reported.的解决方法
date: '2019-11-03 18:04:47'
updated: '2019-11-03 19:35:50'
tags: [linux, docker]
permalink: /articles/2019/11/03/1572775487306.html
---
![](https://img.hacpai.com/bing/20180215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 这是普通用户没有权限使用sudo命令，在/etc/sudoers里添加普通用户即可。
* 第一步：切换到root用户
```shell
$ su root
```
* 第二步：添加sudo文件的写权限,命令是
```shell
$ chmod u+w /etc/sudoers
```
* 第三步：编辑sudoers文件
```shell
$ vi /etc/sudoers
找到这行 root ALL=(ALL) ALL,在他下面添加xxx ALL=(ALL) ALL (这里的xxx是你的用户名)
ps:这里说下你可以sudoers添加下面四行中任意一条  
youuser            ALL=(ALL)                ALL  
%youuser           ALL=(ALL)                ALL  
youuser            ALL=(ALL)                NOPASSWD: ALL  
%youuser           ALL=(ALL)                NOPASSWD: ALL
第一行:允许用户youuser执行sudo命令(需要输入密码).   
第二行:允许用户组youuser里面的用户执行sudo命令(需要输入密码).   
第三行:允许用户youuser执行sudo命令,并且在执行的时候不输入密码.   
第四行:允许用户组youuser里面的用户执行sudo命令,并且在执行的时候不输入密码.
```
* 补充：撤销sudoers文件写权限,命令
```shell
$ chmod u-w /etc/sudoers
```
这样普通用户就可以使用sudo了

