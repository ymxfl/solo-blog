title: Android9.0发送http请求报Network request faild
date: '2019-11-06 12:38:20'
updated: '2019-11-06 12:38:20'
tags: [android]
permalink: /articles/2019/11/06/1573015100310.html
---
### 官网文档：

Android致力于保护用户，他们的设备和数据安全。我们保证数据安全的方法之一是保护所有进入或离开Android设备的数据在传输中使用传输层安全性（TLS）。正如我们在Android P开发人员预览中所宣布的那样，我们通过阻止针对Android P的应用程序默认允许未加密的连接来进一步改进这些保护。  
这是我们多年来为更好地保护Android用户而做出的各种更改。为了防止意外的未加密连接，我们android:usesCleartextTraffic在Android Marshmallow中引入了manifest属性。在Android Nougat中，我们通过创建Network Security Config功能扩展了该属性，该功能允许应用程序指示他们不打算在没有加密的情况下发送网络流量。在Android Nougat和Oreo中，我们仍然允许明文连接。

---
看来以后都要用https了，在Android P系统的设备上，如果应用使用的是非加密的明文流量的http网络请求，则会导致该应用无法进行网络请求，https则不会受影响，同样地，如果应用嵌套了webview，webview也只能使用https请求。
**目前找到的解决办法：**  
* 1：改用https
* 2：添加配置文件
* * 2.1：在res的xml目录下，新建一个xml文件(名称自定义,如：network_security_config.xml)，  
内容如下：
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true" />
</network-security-config>
```
![image.png](https://img.hacpai.com/file/2019/11/image-997d4c22.png)

* * 2.2：在AndroidManifest.xml里添加
```xml
android:networkSecurityConfig="@xml/network_security_config"
```
![image.png](https://img.hacpai.com/file/2019/11/image-ef326154.png)


