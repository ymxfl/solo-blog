title: React-Native Android集成Code-Push 热更新
date: '2019-11-07 23:47:24'
updated: '2019-11-08 09:41:34'
tags: [react-native]
permalink: /articles/2019/11/07/1573141644720.html
---
![](https://img.hacpai.com/bing/20190103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1. code-push常用命令

* **安装客户端**: `npm install -g code-push-cli`
* **注册账号**: `code-push register`(自建服务不需要注册)
* **登陆**: `code-push login <address>`
例如：
```
code-push login http://localhost:3000
```
![image.png](https://img.hacpai.com/file/2019/11/image-9a75d2a1.png)

执行完后会自动打开浏览器,输入用户密码密码后跳转到获取token页面

![image.png](https://img.hacpai.com/file/2019/11/image-7e17565c.png)

点击获取token，将生成的token复制到控制台

![image.png](https://img.hacpai.com/file/2019/11/image-28ba71c8.png)

![image.png](https://img.hacpai.com/file/2019/11/image-4ec23e6a.png)

此处可以看到登陆成功，并且将登陆信息持久化保存到了文件里，只要文件不删除，就不需要重新登陆。`Your session file was written to C:\Users\42556\AppData\Local\.code-push.config`，当再次登陆时会提示!

[image.png](https://img.hacpai.com/file/2019/11/image-f8075c39.png)


* **注销**: `code-push logout`
注销登陆时会删除用户本地存储的登录信息，当遇到不能正常注销时，可手动删除.code-push.config文件

![image.png](https://img.hacpai.com/file/2019/11/image-7d26536a.png)

* **添加项目**: `code-push app add [app名称] android/ios react-native`
注意：**一定要为 Android 和 iOS 分别注册**，两者的更新包内容会有差异，这里建议在App名称后加上操作系统类型如Android或Ios以方便区分。

![image.png](https://img.hacpai.com/file/2019/11/image-1d456e1d.png)

添加成功后会返回不同运行时环境的Key，比如 `Production`,`Staging`等。

* **删除项目**: `code-push app remove [app名称]`

![image.png](https://img.hacpai.com/file/2019/11/image-12dc5e01.png)

* **列出账号下的所有项目**:`code-push app list`

![image.png](https://img.hacpai.com/file/2019/11/image-15b4879a.png)

* **显示登陆的token**: `code-push access-key ls`

![image.png](https://img.hacpai.com/file/2019/11/image-76619a80.png)

* **删除某个access-key**: `code-push access-key rm <accessKey>`

* **添加协作人员**：`code-push collaborator add <appName> lizhenhua@agree.com.cn` 

* **添加一个部署环境**: `code-push deployment add <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-09ad19ca.png)

* **删除部署**: `code-push deployment rm <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-1588abcf.png)

* **列出应用的部署**: `code-push deployment ls <appName>`

![image.png](https://img.hacpai.com/file/2019/11/image-82918506.png)

* **查询部署环境的key**: `code-push deployment ls <appName> -k`

![image.png](https://img.hacpai.com/file/2019/11/image-f9bd214b.png)

* **查看部署的历史版本信息**: `code-push deployment history <appName> <deploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-f50ae398.png)

* **重命名一个部署环境名称**: `code-push deployment rename <appName> <currentDeploymentName> <newDeploymentName>`

![image.png](https://img.hacpai.com/file/2019/11/image-00d90ccb.png)

### **2.集成到项目**
* **第一步：安装CodePush插件**`npm install -g code-push-cli`
安装完毕后，输入 `code-push -v`查看版本，如看到版本代表成功。
注意：自建code-push-server服务与react-native-code-push版本有强依赖关系，如果对应有问题则会导致无法正常更新，本项目rn版本`0.60.4`,使用code-push-server版本为`0.5.4`,react-native-code-push插件版本0.5.6。我尝试使用最新的code-push插件版本为0.5.7，但服务请求路径完全不配套。目前code-push与rn版本的对应关系如下![image.png](https://img.hacpai.com/file/2019/11/image-ae082d64.png)

* **第二步：引入到项目里**
	* 2.2.1 自动引入`react-native link react-native-code-push`（建议手动引入，这样清楚具体添加了哪些内容）
	* 2.2.2 手动引入
在 android/app/build.gradle文件里面添如下代码:
```js
apply from: "../../node_modules/react-native-code-push/android/codepush.gradle"
dependencies {
...
    implementation project(':react-native-code-push')
}
并修改defaultConfig中的versionName为三位(默认为1.0)，如1.0.0
```
然后在/android/settings.gradle中添加如下代码:
```js
include ':react-native-code-push'
project(':react-native-code-push').projectDir = new File(rootProject.projectDir, '../node_modules/react-native-code-push/android/app')
```
* **第三步：运行** `code-push deployment -k ls <appName>`**获取 部署秘钥**。默认的部署名是 staging，所以 部署秘钥（deployment key ） 就是 staging。

* **第四步：添加配置**。当APP启动时我们需要让app向CodePush咨询JS bundle的所在位置，这样CodePush就可以控制版本。更新 MainApplication.java文件
```java
public class MainApplication extends Application implements ReactApplication {
  private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
    @Override
    protected boolean getUseDeveloperSupport() {
      return BuildConfig.DEBUG;
    }
    @Override
    protected String getJSBundleFile() {
      return CodePush.getJSBundleFile();
    }
    @Override
    protected List<ReactPackage> getPackages() {
      // 3. Instantiate an instance of the CodePush runtime and add it to the list of
      // existing packages, specifying the right deployment key. If you don't already
      // have it, you can run "code-push deployment ls <appName> -k" to retrieve your key.
      return Arrays.<ReactPackage>asList(
        new MainReactPackage(),
        new CodePush("deployment-key-here", MainApplication.this, BuildConfig.DEBUG,"YOUR_SERVER_URL")
      );
    }
  };
  @Override
  public ReactNativeHost getReactNativeHost() {
      return mReactNativeHost;
  }
}
```
别忘了
```java
import com.microsoft.codepush.react.CodePush;
```
**关于deployment-key的设置**

在上述代码中我们在创建CodePush实例的时候需要设置一个deployment-key,因为deployment-key分生产环境与测试环境两种,所以建议大家在build.gradle中进行设置。在build.gradle中的设置方法如下:

打开android/app/build.gradle文件,找到`android { buildTypes {} }`然后添加如下代码即可:

```js
android {
    ...
    buildTypes {
        debug {
            ...
            // CodePush updates should not be tested in Debug mode
            ...
        }

        releaseStaging {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"<INSERT_STAGING_KEY>"'
            ...
        }

        release {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"<INSERT_PRODUCTION_KEY>"'
            ...
        }
    }
    ...
}
```
> 心得:另外,我们也可以将deployment-key存放在local.properties中:

```properties
code_push_key_production=erASzHa1-wTdODdPJDh6DBF2Jwo94JFH08Kvb
code_push_key_staging=mQY75RkFbX6SiZU1kVT1II7OqWst4JFH08Kvb
```
然后在就可以在android/app/build.gradle可以通过下面方式来引用它了:

```js
Properties properties = new Properties()
properties.load(project.rootProject.file('local.properties').newDataInputStream())
android {
    ...
    buildTypes {
        debug {
            ...
            // CodePush updates should not be tested in Debug mode
            ...
        }

        releaseStaging {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"'+properties.getProperty("code_push_key_production")+'"'
            ...
        }

        release {
            ...
            buildConfigField "String", "CODEPUSH_KEY", '"'+properties.getProperty("code_push_key_staging")+'"'
            ...
        }
    }
    ...
}
```
在android/app/build.gradle设置好deployment-key之后呢,我们就可以这样使用了:

```java
@Override
protected List<ReactPackage> getPackages() {
     return Arrays.<ReactPackage>asList(
         ...
         new CodePush(BuildConfig.CODEPUSH_KEY, MainApplication.this, BuildConfig.DEBUG), // Add/change this line.
         ...
     );
}
```
至此Code Push for Android的SDK已经集成完成。（先睡觉，未完待续。。。）
