title: Linux普通用户安装mysql
date: '2019-10-19 14:40:20'
updated: '2019-10-19 14:56:32'
tags: [linux, mysql]
permalink: /articles/2019/10/19/1571467219950.html
---
![](https://img.hacpai.com/bing/20181015.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

 如果服务器已经安装过mysql，或者没有root权限，我们可以使用普通用户安装mysql。安装步骤如下 ：
### 1、下载mysql安装包，放到当前普通用户目录下解压。
```shell
[user@localhost ~]$ tar -zxvf mysql-5.7.24-linux-glibc2.12-x86_64.tar.gz  
[user@localhost ~]$ mv mysql-5.7.24-linux-glibc2.12-x86_64 mysql
```
### 2、编辑my.cnf配置文件，放在当前mysql安装目录下，配置文件路径/home/user/mysql/my.cnf 。
```shell
[user@localhost ~]$ cd mysql
[user@localhost mysql]$ vi my.cnf
#添加以下内容
[client]   
port=3336  
socket=/home/user/mysql/mysql.sock  
[mysqld]
port=3336
basedir=/home/user/mysql
datadir=/home/user/mysql/data
pid-file=/home/user/mysql/mysql.pid
socket=/home/user/mysql/mysql.sock
log_error=/home/user/mysql/error.log
server-id=100
```
### 3、进入mysql目录，开始安装mysql。
```shell
[user@localhost mysql]$ bin/mysqld --defaults-file=/home/user/mysql/my.cnf --initialize --user=user --basedir=/home/user/mysql --datadir=/home/user/mysql/data
#--defaults-file 指定配置文件
#--initialize 自动生成带随机密码的root用户
```
### 4、启动停止mysql
```shell
[user@localhost mysql]$ bin/mysqld_safe --defaults-file=/home/user/mysql/my.cnf --user=user &
[user@localhost mysql]$ bin/mysqladmin shutdown -u root -p -S /home/user/mysql/mysql.sock
#./mysqld_safe启动mysql会默认寻找/etc/my.cnf配置文件。普通用户没有权限，因此要通过--defaults-file指定我们自定义的配置文件
#bin/mysqld_safe: line 647: /var/log/mariadb/mariadb.log: No such file or directory
# 启动报错：mysqld_safe error: log-error set to '/var/log/mariadb/mariadb.log', however file don't exists. Create writable for user '2iuser'.bin/mysqld_safe: line 144: /var/log/mariadb/mariadb.log: No such file or directory
#当前系统中安装了mariadb，mariadb的配置文件路径/etc/my.cnf，mysql根据配置文件无法找到相关的文件，所以报错。
#查找mariadb，删除mariadb。
[user@localhost mysql]$ rpm -qa | grep mariadb
[user@localhost mysql]$ rpm -e mariadb-libs-5.5.56-2.el7.x86_64
```
### 5、在error.log文件中获取root用户密码。
```shell
[user@localhost mysql]$ cat error.log | grep root@localhost
```
### 6、安装完成，使用root用户登陆mysql。
```shell
[user@localhost mysql]$ bin/mysql -u root -p -S /home/user/mysql/mysql.sock
Enter password: 
#如果不加-S登录时会报错 ERROR 2002 (HY000): Can't connect to local MySQL server through socket '/tmp/mysql.sock' (2)
#其中一种解决方法是在命令行里指定sock文件即可登陆，由于本机已安装mysql数据库，sock文件在/tmp/mysql.sock已存在，所以建议这种方式登录，后续再想办法优化。
[user@localhost mysql]$ bin/mysql -u root -p -S /home/user/mysql/mysql.sock
#由于mysql是在路径/tmp/mysql.sock寻找sock文件，我们配置文件里指定的路径是/home/2iuser/mysql/mysql.sock，所以加上软连接即可。
[user@localhost mysql]$ ln -s /home/user/mysql/mysql.sock /tmp/mysql.sock
```
### 7、修改root密码。
```mysql
mysql> set password=password('root');
Query OK, 0 rows affected, 1 warning (0.00 sec)
```
### 8、修改权限使远程客户端可以连接。
```
mysql> use mysql
Database changed
mysql> select host,user from user;
+-----------+---------------+
| host      | user          |
+-----------+---------------+
| localhost | mysql.session |
| localhost | mysql.sys     |
| localhost | root          |
+-----------+---------------+
3 rows in set (0.00 sec)
 
mysql> grant all privileges on *.* to 'root'@'%' identified by 'root';
Query OK, 0 rows affected, 1 warning (0.00 sec)
 
mysql> flush privileges;
Query OK, 0 rows affected (0.00 sec)
 
mysql> select host,user from user;
+-----------+---------------+
| host      | user          |
+-----------+---------------+
| %         | root          |
| localhost | mysql.session |
| localhost | mysql.sys     |
| localhost | root          |
+-----------+--------------
4 rows in set (0.00 sec)
```
