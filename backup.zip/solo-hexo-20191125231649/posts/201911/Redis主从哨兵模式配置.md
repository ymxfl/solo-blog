title: Redis主从+哨兵模式配置
date: '2019-11-08 11:12:14'
updated: '2019-11-08 15:32:25'
tags: [redis]
permalink: /articles/2019/11/08/1573182734655.html
---
![](https://img.hacpai.com/bing/20180522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1. 解压redis
```shell
$ tar-zxvf redis-4.0.10.tar.gz
#(主redis)
$ mv redis-4.0.10 redisMaster
```
### 2. 进入redisMaster目录执行make命令
```shell
$ cd redisMaster
$ make
```
### 3.复制redisMaster作为从redis
```shell
$ cp -r redisMaster redisSlave
```
### 4. 编辑redis.conf
```shell
$ cd redisMaster

$ mv redis.conf 6379.conf

$ vi 6379.conf

```
修改bind127.0.0.1 为bind 192.168.109.100（本机ip）

新增requirepass redis

新增 masterauth redis

修改protected-mode 为 no

修改daemonize 为yes 　　#启用守护模式

默认情况下，redis node和sentinel的protected-mode都是yes，在搭建集群时，若想从远程连接redis集群，需要将redis node和sentinel的protected-mode修改为no，若只修改redis node，从远程连接sentinel后，依然是无法正常使用的，且sentinel的配置文件中没有protected-mode配置项，需要手工添加。依据redis文档的说明，若protected-mode设置为no后，需要增加密码验证或是IP限制等保护机制，否则是极度危险的。

同样修改redisSlave里的配置。
```shell
$ cd redisSlave

$ mv redis.conf 6380.conf

$ vi 6380.conf
```
修改 bind 127.0.0.1 为bind 192.168.109.100，

修改protected-mode 为 no，

修改port 6379 为 6380

新增requirepass redis

修改daemonize 为yes 　　#启用守护模式

新增masterauth redis

修改pidfile 为/var/run/redis_6380.pid

新增 slaveof 127.0.0.1 6379(主redis的ip和端口)

至此redis的主从模式配置完成

### 5.启动主从redis
```shell
$ cd redisMaster/src

# 启动主redis

$ ./redis-server ../6379.conf

$ cd redisSlave/src

# 启动从redis

$ ./redis-server ../6380.conf
```
### 6.测试主从
```shell
$ cd /redisMaster/src
```
执行登录命令
```shell
$ ./redis-cli -a redis -p 6379 -h 192.168.109.100
# 参数说明：-a：密码 ,-p 端口，-h ip地址
```
登录成功之后 存入一条数据测试
![image.png](https://img.hacpai.com/file/2019/11/image-e297e1ed.png)

登录从redis
```shell
$ cd redisSlave/src
```
登录查看
![image.png](https://img.hacpai.com/file/2019/11/image-2c96776c.png)

### 7.配置哨兵模式
重新安装一个redis命名为redisSentinel
```shell
$ cd redisSentinel
```
修改sentinel.conf配置文件内容如下
```shell
修改protected-mode 为 no

port 26379

daemonize yes

sentinel monitor mymaster 192.168.109.100 6379 1 #哨兵监控的master

sentinel down-after-milliseconds mymaster 5000 #master或者slave多少时间（默认30秒）不能使用标记为down状态

sentinel failover-timeout mymaster 9000 #若哨兵在配置值内未能完成故障转移操作，则任务本次故障转移失败。

sentinel auth-pass mymaster redis #如果redis配置了密码，那这里必须配置认证，否则不能自动切换
```
### 8.启动哨兵
```shell
$ cd redisSentinel/src

./redis-sentinel ../sentinel.conf
```
### 9.查看哨兵信息
```shell
$ cd redisSentinel/src

$ ./redis-cli -p 26379 -h 192.168.109.100

```
  
输入info
![image.png](https://img.hacpai.com/file/2019/11/image-3bad1211.png)
### 10.将redis启动命令添加到系统命令(选配)
* 10.1设置redis.conf中daemonize为yes,确保守护进程开启,也就是在后台可以运行
```shell
 #vi编辑redis安装目录里面的redis.conf文件
[root@localhost /]$ vi redis.conf
```
![image.png](https://img.hacpai.com/file/2019/11/image-4dcb5be8.png)
* 10.2 复制redis配置文件(启动脚本需要用到配置文件内容,所以要复制)
```shell
#1.在/etc下新建redis文件夹

[root@localhost /]$ mkdir /etc/redis

#2.把安装redis目录里面的redis.conf文件复制到/etc/redis/6379.conf里面,

6379.conf是取的文件名称,启动脚本里面的变量会读取这个名称,所以要是redis的端口号改了,这里也要修改

[root@localhost redis]$ cp /home/redis/redis/redis.conf /etc/redis/6379.conf
```
* 10.3复制redis启动脚本
```shell
#1.redis启动脚本一般在redis根目录的utils,如果不知道路径,可以先查看路径

[root@localhost redis]$ find / -name redis_init_script

/home/redis/redis/utils/redis_init_script

#2.复制启动脚本到/etc/init.d/redis文件中

[root@localhost redis]$ cp /home/redis/redis//utils/redis_init_script /etc/init.d/redis
```
10.4 修改启动脚本参数
```shell
[root@localhost redis]$ vi /etc/init.d/redis

#在/etc/init.d/redis文件的头部添加下面两行注释代码,也就是在文件中#!/bin/sh的下方添加

# chkconfig: 2345 10 90  

# description: Start and Stop redis

#同时还要修改参数,指定redis的安装路径，ip和密码
```
![image.png](https://img.hacpai.com/file/2019/11/image-6f124ccb.png)
![image.png](https://img.hacpai.com/file/2019/11/image-eec37a9d.png)
* 10.5 启动redis
打开redis命令:service redis start
关闭redis命令:service redis stop
设为开机启动:chkconfig redis on
设为开机关闭:chkconfig redis off




