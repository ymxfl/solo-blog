title: Jasypt Spring Boot 为 Spring Boot 项目中的属性源加密
date: '2019-10-28 13:11:17'
updated: '2019-10-28 13:21:33'
tags: [随笔]
permalink: /articles/2019/10/28/1572239477712.html
---
Jasypt Spring Boot 为 Spring Boot 项目中的属性源（property sources）提供加密支持。

有三种方法可以在项目中集成 jasypt-spring-boot：

* 如果 Spring Boot 项目中使用了 @SpringBootApplication 或者 @EnableAutoConfiguration ，在项目里添加jasypt-spring-boot-starter 依赖会自动对项目中整个属性（包括系统属性、环境属性、命令行参数、application.properties, yaml）启动加密。
    
* 如果项目里没有使用 @SpringBootApplication 或者 @EnableAutoConfiguration ，可以手动在 Configuration 类上添加注解 @EnableEncryptableProperties ，来在整个环境的属性启用属性加密。
    
* 如果想指定加密文件，可以使用 @EncryptablePropertySource 指定单个属性源。
```java
<dependency>
	<groupId>com.github.ulisesbocchio</groupId>
	<artifactId>jasypt-spring-boot-starter</artifactId>
	<version>${jasypt.version}</version>
</dependency>
```
